import * as D from './decorators';

export const decorators = Object.values(D);
