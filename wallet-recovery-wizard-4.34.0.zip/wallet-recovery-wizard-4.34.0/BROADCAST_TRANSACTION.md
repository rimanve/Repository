# Broadcast Transaction Instructions

WRW natively supports broadcasting transactions from the UI. To do so, select the coin and copy the fully-signed serialized transaction. If using the Offline Vault Console (OVC), use the 'txHex' field from the-fully signed JSON file.

### This feature is currently supported for the following coins -
- HBAR
- ALGO (Note: There is no public node for Algo, so you must input your own node details)
